This module allows access to Palm OS(tm) database files on the desktop 
in pure Python. It is as simple as possible without (hopefully) being 
too simple. As much as possible Python idioms have been used to make
it easier to use and more versatile.

This code is based on code from the Pyrite Project, available I believe
from SourceForge. However the code has been modified so extensively it's 
hardly recognizable. But without the Pyrite code, PalmDB would not be here
today.